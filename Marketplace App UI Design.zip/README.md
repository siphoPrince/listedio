
  # Marketplace App UI Design

  This is a code bundle for Marketplace App UI Design. The original project is available at https://www.figma.com/design/UTqr9ZicgwJoJ2hHJUFc53/Marketplace-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  